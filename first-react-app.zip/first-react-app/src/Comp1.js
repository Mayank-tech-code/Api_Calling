import React from 'react';

function employye(){
    return 'mayank';
}

function employee2(){
    return 'heelo';
}

export {employye , employee2};