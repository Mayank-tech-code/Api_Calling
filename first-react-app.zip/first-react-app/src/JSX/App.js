// Always write in fragment 
// if else is not allowed istead ternary operator 
// {} for javscript 

import react from 'react';

const App=()=>{
    const x=10;

    return (
        
        <h1>{(x)>10 ? 'greater ' : 'smaller'} </h1>
    );
};

export default App;