import React from 'react';


function Para(){
    return <p>paragraph one</p>
}

export default Para();
