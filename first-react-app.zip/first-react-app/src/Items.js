const Items = [
    {
         id : 1,
        name : 'Laptop',
        price: 50000
    },
    {
        id : 2,
        name : 'Phone',
        price: 20000
    },
    {
        id : 3,
        name : 'TV',
        price: 5000
    }
];

export default Items;