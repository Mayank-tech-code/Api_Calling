// import React from 'react';
// import ReactDOM from 'react-dom';

// ReactDOM.render(<h1>heelo World</h1>,
// document.getElementById('root')
// );



// -------------------------------------------------
// How to render multiple JSX elements in react 

// import React from 'react';
// import ReactDOM from 'react-dom';


// render method can render mutile JSX  Element by <></>
// ReactDOM.render(
//     <>
//     <h1>Heelo World</h1>
//     <p> Paragraph</p>
//     </>
//     ,document.getElementById('root')
// );


// ReactDOM.render(
//     [
//        <h1>Heading One</h1>,
//        <p>Paragraph One </p>
//     ],
//     document.getElementById('root')
// );

// --------------------------------------------------


// JSX CHALLENGE VIDEO-10

// import react from 'react';
// import reactDOM from 'react-dom';

// ReactDOM.render(
// <>
// <h1>Heading One </h1>
// <p> Paragraph</p>
// <ol>
//     <li> Mango</li>
//     <li>Orange  </li>
// </ol>
// </>,
// document.getElementById('root'));


// --------------------------------------------------

// VIDEO 11 JSX Expression 

// How to USE javascript in HTMl with help of {} 
// {} can be used only for expression not statement 

// import React from 'react';
// import ReactDOM from 'react-dom';


// const fname = 'mayank';

// function myName(Text){
//     return Text;
// }
// ReactDOM.render(
//     <>
//     <h1>My Name is {myName('hello')}</h1>
//     <p>My lucky No {2+8}</p>
//     </>
//     ,document.getElementById('root')
// );

// --------------------------------------------------------

// Challenge 
// import React from 'react';
// import ReactDOM from 'react-dom';

// const date = new Date();

// ReactDOM.render(
//     <>
//         <h1>Heading ONe </h1>
//         <p> {`Today Current Date Is ${date}` }</p>

//     </>,
//     document.getElementById('root')
// );

// -------------------------------------------------------

// Component in reactjs 

// import React from 'react';
// import ReactDOM from 'react-dom';
// import Heading from "./Head";
// import Para  from './Para.js';

// ReactDOM.render(
//     <>
//     <Heading/>
//     <Para/>
//     </>
//     ,document.getElementById('root')
// );

// -----------------------------------------------------------

// CalCuator (video 22)

// import React from 'react';
// import ReactDOM from 'react-dom';
// import Button from 'react-bootstrap/Button';

// import 'bootstrap/dist/css/bootstrap.min.css';
// ReactDOM.render(
//     <>
//       <Button variant="primary">Primary</Button>{' '}
//       <Button variant="secondary">Secondary</Button>{' '}
//       <Button variant="success">Success</Button>{' '}
//       <Button variant="warning">Warning</Button>{' '}
//       <Button variant="danger">Danger</Button>{' '}
//       <Button variant="info">Info</Button>{' '}
//       <Button variant="light">Light</Button>{' '}
//       <Button variant="dark">Dark</Button>
//       <Button variant="link">Link</Button>

//     </>,
//     document.getElementById('root')
// );


// --------------------------------------------------------------

// Name display App Using Props 

// import React from 'react';
// import ReactDOM from 'react-dom';
// import NameDisplay from './NameDisplay';

// ReactDOM.render(
//     <>
//         <NameDisplay/>
//     </>,
//     document.getElementById('root')
// );


// import React from 'react';
// import ReactDOM from 'react-dom';

// // import App from './useContextHook/App.js';
// // import App from './useCallback/App.js';
// import App from './Form_Controlled_Uncontroleed/App.js';

// ReactDOM.render(
//   <>
//     <App/>
//   </>,
//   document.getElementById('root')
// );


/////////////////////////////////////

// Api fetching Data 
import React from "react";
import ReactDOM  from "react-dom";
// import { BrowserRouter } from "react-router-dom";
// import App from './Displat_Contact_Api/App.js';
import App from './SecondApi/App';


ReactDOM.render(
  <>
    <App/>
  </>,
  document.getElementById('root')
);