import React from 'react';

import {sum, sub , mul , div} from './Calc';


const App =()=>{
    return (
        <>
        <h1> Sum Of Two No is {sum(2,3)}</h1>
        <h1> sub Of Two No is {sub(2,3)}</h1>
        <h1> mul Of Two No is {mul(2,3)}</h1>
        <h1> div Of Two No is {div(2,3)}</h1>

    </> 
    );
}

export default App;