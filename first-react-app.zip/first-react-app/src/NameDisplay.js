import React from 'react';

NameDisplay = ()=>{
    return <h1> Your Name </h1>
}

export default NameDisplay;