import React from 'react';

function Order(){
    return (
        <ol>
            <li>Mango</li>
            <li> Orange</li>
        </ol>
    )

};


export default Order;