import React, { useState } from 'react'

const App = () => {
  const [name , setName] = useState("");
  const [pswd , setPswd] = useState("");
  function handleChange(e){
    // console.log(e.target.value);
    if(e.target.name =='firstName'){
      setName(e.target.value);
    }
    else{
      setPswd(e.target.value);
    }
    
    // setName(e.target.value); //used to display in input field


  }

  // function handlePassword(e){
  //   console.log(e.target.value);
  //   setPswd(e.target.value);


  // }

  return (
    <>
      <form>
        <label >First Name : </label><br/>
        {/* <input type="text" value='john'/><br/>  */}
        {/* value` prop to a form field without an `onChange` handler. 
        This will render a read-only field. If the field should be mutable use `defaultValue`. 
        Otherwise, set either `onChange` or `readOnly`.
        at input
        at form
        at App */}

        {/* onChange Handler return an event object  */}

        <input type="text" name='firstName' value={name} onChange={handleChange}/><br/>
        <label>Password</label><br />
        <input type="text" name='password' value={pswd} onChange={handleChange}/><br/>
      </form>
    </>
  )
}

export default App


