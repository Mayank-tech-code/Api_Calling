import {React,createContext} from 'react';
import ChildA from './ChildA';


// what is Context Api
// create , provider , consumer
// How to use it 
// is context api also problematic  

// i need to pass data from Appjs to childB component 
// context api is 

const data = createContext();

const App = ()=>{
    const name = "Mayank";
    return (
        <>
            <data.Provider value={name}>
            <ChildA/>
            </data.Provider>
            
        </>

    );
}

export default App;

export {data};