import React from 'react';
import ChildB from './ChildB';



const ChildA =()=>{
    return (
        <>
            <ChildB/>
        </>

    );
};

export default ChildA;