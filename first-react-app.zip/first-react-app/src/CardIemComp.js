import React from 'react';

enterDetaisl = (props) =>{
    return (
        `you enter ${props.item}`
    )
}

export default 