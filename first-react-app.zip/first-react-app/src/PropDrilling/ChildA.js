import React from 'react';
import ChildB from './ChildB';

const ChildA=({name})=>{
    
    return (
        <>
            <h1> Component Child A </h1>
            <ChildB name = {name} />
        </>
    );
};

export default ChildA;