import React from 'react';


const ChildB=(Props)=>{
    const Fname = 'mayank';
    return (
        <>
            <h1> my fname is {Props.name} </h1>
            <h2>Component ChildB </h2>
        </>
    );
};

export default ChildB;