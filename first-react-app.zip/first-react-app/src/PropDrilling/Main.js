import React from 'react';
import ChildA from './ChildA';

const Main=()=>{
    const Fname = 'Agrawal';
    return (
        <>
            <h1> Prop Drilling</h1>
            <h1> i want to pass data from Main to ChildB </h1>
            <h1> But i dont want to use middle child </h1>
            <h1> to Avooid such Situsation we use context Api </h1>
            <ChildA name={Fname} />
        </>
    );
};

export default Main;