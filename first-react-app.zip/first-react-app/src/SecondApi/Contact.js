
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {  useParams } from 'react-router-dom';

const Contact = () => {
    const [user, setUser] = useState({});

    const { id } = useParams();
    
    useEffect( () => {
      axios.get(`http://localhost:3004/friends/${id}/contact`)
        .then(response => {

           
          console.log(response);
          setUser(response.data);
        })
        .catch(error => {
          console.error('Error fetching user data:', error);
        });

    }, [id]);
    

    return (
      <>
            <h2>User Data:</h2>
            <p>Email: {user.email}</p> 
            <p>Phone: {user.phone}</p>
              
      </>
    );
  };
  
  export default Contact;