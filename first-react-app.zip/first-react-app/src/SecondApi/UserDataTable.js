import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const UserDataTable = () => {
  const [userData, setUserData] = useState([]);
  const [selectedContact, setSelectedContact] = useState();

  useEffect(() => {
    axios
      .get('http://localhost:3004/friends')
      .then(response => {
        console.log(response);
        setUserData(response.data);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }, []);

  const handleButtonClick = (index) => {
    // console.log(selectedContact);
    // console.log(index);
    // console.log(userData[index]);
    setSelectedContact(userData[index]);
  };

  return (
    <>
      <h2>User Data Table:</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Link</th>
          </tr>
        </thead>
        <tbody>
          {userData.map((item, index) => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td>
              <Link to={`/friends/${item.id}`}><button onClick={() => handleButtonClick(index)}>{item.name}</button> {item.id}</Link>

                
              </td>
              {/* <td>
                <Link to={`/friends/${item.id}/contact`}>View {item.name}</Link>
              </td> */}
              <td>
                <Link to={`/friends/${item.id}`}>View {item.id}</Link>
              </td>
              
            </tr>
          ))}
        </tbody>
      </table>

      {selectedContact && (
        <div>
          <h3>Contact Details for {selectedContact.name}:</h3>
           <p>Email: {selectedContact.contact.email}</p>
          <p>Phone: {selectedContact.contact.phone}</p>
        </div>
       )}
        
    </>
  );
};

export default UserDataTable;
