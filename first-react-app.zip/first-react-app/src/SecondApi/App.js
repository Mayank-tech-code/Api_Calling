
import React from 'react';
import {BrowserRouter,Route, Routes } from 'react-router-dom';

import UserDataTable from './UserDataTable';
import UserData from './UserData';
import Contact from './Contact';

const App = () => {
    
    return (
    <BrowserRouter>
     <Routes>
        <Route  path="/" element={<UserDataTable />} />    
        <Route path="/friends/:id" element={<UserData />} />
        <Route path="/friends/:id/contact" element={<Contact />} />


      </Routes>
    </BrowserRouter>
    );
  };
  
export default App;

