
import React from 'react';
import {BrowserRouter,Route, Routes } from 'react-router-dom';

import UserDataTable from './UserDataTable';
import UserData from './UserData';

const App = () => {
    
    return (
    <BrowserRouter>
     <Routes>
        <Route  path="/" element={<UserDataTable />} />    
        <Route path="/friends/:id" element={<UserData />} />
      </Routes>
    </BrowserRouter>
    );
  };
  
export default App;

