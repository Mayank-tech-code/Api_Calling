// ContactDetails.jsx
import React from 'react';

const ContactDetails = ({ contact }) => {
  return (
    <div>
      <h3>Contact Details for {contact.name}:</h3>
      <p>Email: {contact.contact.email}</p>
      <p>Phone: {contact.contact.phone}</p>
    </div>
  );
};

export default ContactDetails;
