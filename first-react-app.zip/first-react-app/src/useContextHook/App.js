import React , {createContext} from 'react';
import {ChildA} from './ChildA';

// What is useCOntext Hook 
// passing data from main to ChildB 
// without involving ChildA  without using ContextApi
// create , Provider, useCOntext
// How to use it 

const data = createContext();
const data1 = createContext();

const App = ()=>{
    const name = 'Mayank';
    const gender = 'M';
    return (
        <>
        <data.Provider value={name}>
            <data1.Provider value={gender}>
            
                <ChildA/>
            
            </data1.Provider>
        </data.Provider>
        </>

    );
};

export {App , data , data1};
export default App;
