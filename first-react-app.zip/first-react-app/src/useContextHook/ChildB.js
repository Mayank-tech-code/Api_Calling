import React,{useContext}from 'react';
import {data , data1 } from './App';

const ChildB=()=>{
    const Fname = useContext(data);
    const gender = useContext(data1);

    return (
        <>
            <h1> Hi MY name is {Fname}  and my gender is {gender} </h1>
        </>

    );
};


export {ChildB};