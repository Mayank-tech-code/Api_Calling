import React from 'react';



function Head(){
    return <h1>My name is mayank</h1>
}

export default Head;