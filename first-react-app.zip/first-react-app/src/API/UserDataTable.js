import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link} from 'react-router-dom';

const UserDataTable = () => {
  const [userData, setUserData] = useState([]);
  

  useEffect(() => {
    axios
      .get('http://localhost:3004/friends')
      .then(response => {
        console.log(response);
        setUserData(response.data);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }, []);

  return (
    <>
      <h2>User Data Table:</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Link</th>
          </tr>
        </thead>
        <tbody>
          {userData.map(item => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td><button>{item.name}</button></td>
              
              <td>
                <Link to={`/friends/${item.id}`}>View {item.id}</Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
};


export default UserDataTable;



 

      


      
