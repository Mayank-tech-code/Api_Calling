
// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { Link } from 'react-router-dom';

// import data from '../data.json'; 


// const Home = () => {

//   const [userdata, setData] = useState([]);

//   useEffect(() => {
//     axios.get('http://localhost:3004/friends')
//       .then(response => {
//         console.log(response);
//         setData(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching data:', error);
//       });
//   }, []);


// // //   --------------------------------------------
// // Using My Own Json Data 


// const [myuserdata, setUserData] = useState([]);


//   useEffect(() => {
//     setUserData(data.friends);
//   }, []);


//   return (
//     <>

//       <h2>Data Table:</h2>
//       <table>
//         <thead>
//           <tr>
//             <th>ID</th>
//             <th>Name</th>
//             <th>age</th>
//           </tr>
//         </thead>
//         <tbody>
//           {userdata.map(item => (
//             <tr key={item.id}>
//               <td>{item.id}</td>
//               <td>{item.name}</td>
//               <td><Link to={`/friends/${item.id}`}>Vue {item.id}</Link></td>
//              </tr>
//           ))}
//         </tbody>
//       </table>


//       <table>
//         <thead>
//           <tr>
//             <th>ID</th>
//             <th>Name</th>
//             <th>Age</th>
//           </tr>
//         </thead>
//         <tbody>
//           {myuserdata.map(item => (
//             <tr key={item.id}>
//               <td>{item.id}</td>
//               <td>{item.name}</td>
//               <td>                
//                     <Link to={`/friends/${item.id}`}>Vue {item.id}</Link>
//                 </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>


//      </>
//   );
// };

// export default Home;
// -------------------------------------------------



// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { Link } from 'react-router-dom';

// // import data from '../data.json'; 


// const Home = () => {

//   const [userdata, setData] = useState([]);

//   useEffect(() => {
//     axios.get('http://localhost:3004')
//       .then(response => {
//         console.log(response);
//         setData(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching data:', error);
//       });
//   }, []);


// // //   --------------------------------------------
// // Using My Own Json Data 


// // const [myuserdata, setUserData] = useState([]);


// //   useEffect(() => {
// //     setUserData(data.friends);
// //   }, []);


//   return (
//     <>

//       <h2>Data Table:</h2>
//       <table>
//         <thead>
//           <tr>
//             <th>ID</th>
//             <th>Name</th>
//             <th>age</th>
//           </tr>
//         </thead>
//         <tbody>
//           {userdata.map(item => (
//             <tr key={item.id}>
//               <td>{item.id}</td>
//               <td>{item.name}</td>
//               <td><td><Link to={`/friends/${item.id}`}>Vue {item.id}</Link></td></td>
//              </tr>
//           ))}
//         </tbody>
//       </table>


//       {/* <table>
//         <thead>
//           <tr>
//             <th>ID</th>
//             <th>Name</th>
//             <th>Age</th>
//           </tr>
//         </thead>
//         <tbody>
//           {myuserdata.map(item => (
//             <tr key={item.id}>
//               <td>{item.id}</td>
//               <td>{item.name}</td>
//               <td>                
//                     <Link to={`/friends/${item.id}`}>Vue {item.id}</Link>
//                 </td>
//             </tr>
//           ))}
//         </tbody>
//       </table> */}


//      </>
//   );
// };

// export default Home ;


// ----------------------------------------------

// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { Link } from 'react-router-dom';

// // import data from '../data.json'; 


// const App = () => {

//   const [userdata, setData] = useState([]);

//   useEffect(() => {
//     axios.get('https://jsonplaceholder.typicode.com/users')
//       .then(response => {
//         console.log(response);
//         setData(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching data:', error);
//       });
//   }, []);


// // //   --------------------------------------------
// // Using My Own Json Data 


// // const [myuserdata, setUserData] = useState([]);


// //   useEffect(() => {
// //     setUserData(data.friends);
// //   }, []);


//   return (
//     <>

//       <h2>Data Table:</h2>
//       <table>
//         <thead>
//           <tr>
//             <th>ID</th>
//             <th>Name</th>
//             <th>Link</th>
//           </tr>
//         </thead>
//         <tbody>
//           {userdata.map(item => (
//             <tr key={item.id}>
//               <td>{item.id}</td>
//               <td>{item.name}</td>
//               <td><Link to={`/${item.id}`}>Vue {item.id}</Link></td>
//              </tr>
//           ))}
//         </tbody>
//       </table>


//       {/* <table>
//         <thead>
//           <tr>
//             <th>ID</th>
//             <th>Name</th>
//             <th>Age</th>
//           </tr>
//         </thead>
//         <tbody>
//           {myuserdata.map(item => (
//             <tr key={item.id}>
//               <td>{item.id}</td>
//               <td>{item.name}</td>
//               <td>                
//                     <Link to={`/friends/${item.id}`}>Vue {item.id}</Link>
//                 </td>
//             </tr>
//           ))}
//         </tbody>
//       </table> */}


//      </>
//   );
// };

// export default App;
// ------------------------------------------------------
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {  useParams } from 'react-router-dom';

const UserData = () => {
    const [user, setUser] = useState(null);
    const { id } = useParams();
  
    useEffect(() => {
      axios
        .get(`https://jsonplaceholder.typicode.com/users/${id}`)
        .then(response => {
          console.log(response);
          setUser(response.data);
        })
        .catch(error => {
          console.error('Error fetching user data:', error);
        });

    }, [id]);

    return (
      <>
        {user ? (
          <>
            <h2>User Data:</h2>
            <p>ID: {user.id}</p>
            <p>Name: {user.name}</p>
            <p>Email: {user.email}</p>
          
          </>
        ) : (
          <p>Loading user data...</p>
        )}
      </>
    );
  };
  
  export default UserData;