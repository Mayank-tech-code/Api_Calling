
// import React from 'react';
// import { Route, Routes } from 'react-router-dom';
// import Home from './Home';
// // import FriendData from './FriendData';

// const App = () => {
//   return (
    
//       <Routes>
//         <Route exact path="/" component={Home} />
//         {/* <Route path="/friends/:id" component={FriendData} /> */}
//       </Routes>
      

//   );
// };

// export default App;
// ---------------------------------------------------
// // Running Code for External APi 
// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { Link, useParams } from 'react-router-dom';

// const App = () => {
//   const [userdata, setUserData] = useState([]);
//   const [selectedUser, setSelectedUser] = useState(null);
//   const { id } = useParams();

//   useEffect(() => {
//     axios
//       .get('https://jsonplaceholder.typicode.com/users')
//       .then(response => {
//         console.log(response);
//         setUserData(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching data:', error);
//       });
//   }, []);

//   useEffect(() => {
//     const fetchUserData = async () => {
//       try {
//         const response = await axios.get(
//           `https://jsonplaceholder.typicode.com/users/${id}`
//         );
//         console.log(response);
//         setSelectedUser(response.data);
//       } catch (error) {
//         console.error('Error fetching data:', error);
//       }
//     };

//     if (id) {
//       fetchUserData();
//     }
//   }, [id]);

//   return (
//     <>
//       <h2>Data Table:</h2>
//       <table>
//         <thead>
//           <tr>
//             <th>ID</th>
//             <th>Name</th>
//             <th>Link</th>
//           </tr>
//         </thead>
//         <tbody>
//           {userdata.map(item => (
//             <tr key={item.id}>
//               <td>{item.id}</td>
//               <td>{item.name}</td>
//               <td>
//                 <Link to={`/${item.id}`}>Vue {item.id}</Link>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>

//       {selectedUser && (
//         <div>
//           <h2>User Data:</h2>
//           <p>ID: {selectedUser.id}</p>
//           <p>Name: {selectedUser.name}</p>
//           <p>Email: {selectedUser.email}</p>
//           {/* Display other user data properties as needed */}
//         </div>
//       )}
//     </>
//   );
// };

// export default App;



import React from 'react';

import {Route, BrowserRouter as Router } from 'react-router-dom';
import UserDataTable from './UserDataTable';
import UserData from './UserData';

const App = () => {
    return (
      <Router>
        <Route path="/" component={UserDataTable} />
        <Route path="/users/:id" component={UserData} />
      </Router>
    );
  };
  
  export default App;
